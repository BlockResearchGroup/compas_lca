import os
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

# =========================
# EDIT THESE TWO PATHS
# =========================
CSV_PATH = r"temp/plots/scripts/tradeoffs_building_element.csv"
OUTPUT_DIR = r"temp/plots/figures/tradeoffs"
output_name = "tradeoff_element.png"
# =========================

MODEL_COLORS = {
    # Anthropic
    "Opus 4.5":   "#1f77b4",
    "Sonnet 4.5": "#4fa3d1",
    "Haiku 4.5":  "#9ecae1",

    # Gemini
    "Gemini 3 Pro":   "#2ca02c",
    "Gemini 3 Flash": "#98df8a",

    # GPT
    "GPT-5.2":    "#d62728",
    "GPT-5 Mini": "#ff9896",
}

# Fixed duration -> linewidth mapping (edit these as you like)
# Interpreted as: if duration <= threshold_seconds -> linewidth
# Linear duration -> linewidth mapping
DURATION_REF_MIN = 5.0    # seconds
DURATION_REF_MAX = 60.0   # seconds
LW_REF_MIN = 1.0          # linewidth at 5s
LW_REF_MAX = 8.0          # linewidth at 60s


def _linewidth_for_duration(duration_s: float) -> float:
    """
    Linear continuous mapping:
    5s  -> 1.0
    60s -> 3.0
    """
    # Clamp to reference range (important for stability)
    duration_s = max(DURATION_REF_MIN, min(duration_s, DURATION_REF_MAX))

    slope = (LW_REF_MAX - LW_REF_MIN) / (DURATION_REF_MAX - DURATION_REF_MIN)
    return LW_REF_MIN + slope * (duration_s - DURATION_REF_MIN)


def main():
    # --- Load CSV (semicolon-separated) ---
    df = pd.read_csv(CSV_PATH, sep=";")

    # --- Validate required columns ---
    required = [
        "Model",
        "Avg. Classification Accuracy [%]",
        "Avg. Attribute Accuracy [%]",
        "Duration/sample [s]",
        "Cost/sample [$]"
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}\nFound columns: {list(df.columns)}")

    # --- Coerce numeric columns ---
    df["Avg. Classification Accuracy [%]"] = pd.to_numeric(
        df["Avg. Classification Accuracy [%]"], errors="coerce"
    )
    df["Avg. Attribute Accuracy [%]"] = pd.to_numeric(
        df["Avg. Attribute Accuracy [%]"], errors="coerce"
    )
    df["Duration/sample [s]"] = pd.to_numeric(
        df["Duration/sample [s]"], errors="coerce"
    )
    df["Cost/sample [$]"] = pd.to_numeric(
        df["Cost/sample [$]"], errors="coerce"
    )

    df = df.dropna(subset=[
        "Avg. Classification Accuracy [%]",
        "Avg. Attribute Accuracy [%]",
        "Duration/sample [s]",
        "Cost/sample [$]"
    ]).copy()

    if (df["Cost/sample [$]"] <= 0).any():
        bad = df.loc[df["Cost/sample [$]"] <= 0, ["Model", "Cost/sample [$]"]]
        raise ValueError(f"All costs must be > 0 for log scale. Bad rows:\n{bad}")

    if (df["Duration/sample [s]"] <= 0).any():
        bad = df.loc[df["Duration/sample [s]"] <= 0, ["Model", "Duration/sample [s]"]]
        raise ValueError(f"All durations must be > 0. Bad rows:\n{bad}")

    # Duration scaling bounds
    dmin = float(df["Duration/sample [s]"].min())
    dmax = float(df["Duration/sample [s]"].max())

    # --- Plot ---
    fig, ax = plt.subplots(figsize=(5, 5.5))

    marker_cls = "o"   # circle
    marker_attr = "s"  # square (use "^" for triangle)

    model_colors = {}

    for _, row in df.iterrows():
        model = row["Model"]
        x = float(row["Cost/sample [$]"])
        y_cls = float(row["Avg. Classification Accuracy [%]"])
        y_attr = float(row["Avg. Attribute Accuracy [%]"])
        duration_s = float(row["Duration/sample [s]"])

        if model not in MODEL_COLORS:
            raise KeyError(
                f"Model '{model}' not found in MODEL_COLORS. "
                f"Available keys: {list(MODEL_COLORS.keys())}"
            )

        color = MODEL_COLORS[model]
        model_colors[model] = color

        lw = _linewidth_for_duration(duration_s)

        # --- Vertical connector line (width encodes duration) ---
        ax.plot(
            [x, x],
            [y_attr, y_cls],
            color=color,
            linewidth=lw,
            alpha=0.9,
            zorder=2
        )

        # --- Markers ---
        ax.scatter(
            x, y_cls,
            s=80,
            marker=marker_cls,
            color=color,
            edgecolor="black",
            linewidth=0.6,
            zorder=3
        )
        ax.scatter(
            x, y_attr,
            s=80,
            marker=marker_attr,
            color=color,
            edgecolor="black",
            linewidth=0.6,
            zorder=3
        )

    ax.set_xscale("log")
    ax.set_xlabel("Cost per sample [$] (log scale)")
    ax.set_ylabel("Accuracy [%]")
    ax.set_title(
        "Trade-offs Building Elements",
        fontsize=10,
        fontweight="semibold",
        pad=6,
    )

    # --- Fixed axis limits ---
    ax.set_ylim(55, 90)
    ax.set_xlim(0.007, 0.12)
    ax.set_yticks([55, 60, 65, 70, 75, 80, 85, 90])

    ax.grid(True, which="both", linestyle="--", linewidth=0.6, alpha=0.6)
    ax.set_axisbelow(True)

    # --- Legends ---

    # 1) Model legend (color → model)
    model_handles = [
        Line2D(
            [0], [0],
            marker="o",
            linestyle="None",
            markersize=8,
            markerfacecolor=color,
            markeredgecolor="black",
            label=model
        )
        for model, color in model_colors.items()
    ]
    legend_models = ax.legend(
        handles=model_handles,
        title="Model",
        loc="lower left",
        frameon=True,
        fontsize=9,
        title_fontsize=10
    )
    ax.add_artist(legend_models)

    # 2) Metric legend (marker shapes)
    metric_handles = [
        Line2D([0], [0], marker=marker_cls, linestyle="None",
            markersize=8, markerfacecolor="white", markeredgecolor="black",
            label="Classification accuracy"),
        Line2D([0], [0], marker=marker_attr, linestyle="None",
            markersize=8, markerfacecolor="white", markeredgecolor="black",
            label="Attribute accuracy"),
    ]
    legend_metrics = ax.legend(
        handles=metric_handles,
        title="Metric",
        loc="upper left",
        frameon=True,
        fontsize=9,
        title_fontsize=10
    )
    ax.add_artist(legend_metrics)

    # 3) Duration legend (linear, fixed reference)
    duration_refs = [5, 15, 30, 60]

    duration_handles = [
        Line2D(
            [0], [0],
            color="black",
            linewidth=_linewidth_for_duration(d),
            label=f"{d:g}s"
        )
        for d in duration_refs
    ]

    legend_duration = ax.legend(
        handles=duration_handles,
        title="Duration / sample",
        loc="lower right",
        frameon=True,
        fontsize=9,
        title_fontsize=10,
        handlelength=2.8
    )
    ax.add_artist(legend_duration)



    # --- Save ---
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_png = os.path.join(OUTPUT_DIR, output_name)

    fig.tight_layout()
    fig.savefig(out_png, dpi=300, bbox_inches="tight")

    print(f"Saved:\n- {out_png}\n")


if __name__ == "__main__":
    main()
