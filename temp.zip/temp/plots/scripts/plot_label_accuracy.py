from pathlib import Path
import re
import pandas as pd
import matplotlib.pyplot as plt

# =========================
# USER-CONFIGURABLE PART
# =========================

INPUT_TXT = Path("temp/plots/scripts/label_accuracy.txt")

OUTPUT_DIR = Path("temp/plots/figures/labels")
OUTPUT_PNG = OUTPUT_DIR / "label_by_label_accuracy.png"

# Explicit y-axis order (TOP → BOTTOM)

MODEL_ORDER = [
    "GPT-5 Mini",
    "GPT-5.2",
    "Gemini 3 Flash",
    "Gemini 3 Pro",
    "Haiku 4.5",
    "Sonnet 4.5",
    "Opus 4.5"
]

FIGSIZE = (9, 5)
DPI = 300

LEGEND_LABELS = {
    "building_element": "Building Elements/Layers",
    "inventory_item": "Inventory Items",
}

# =========================
# PARSE INPUT FILE
# =========================

lines = INPUT_TXT.read_text(encoding="utf-8").splitlines()

pattern = re.compile(
    r"^\s*(building_element|inventory_item)\s+([\d.]+)%\s+\(([\d.]+)/([\d.]+)\)\s*$"
)

rows = []
current_model = None

for line in lines:
    line = line.rstrip()
    if not line or line.startswith("==="):
        continue

    match = pattern.match(line)
    if match:
        label, pct, correct, total = match.groups()
        rows.append({
            "model": current_model,
            "label": label,
            "accuracy_pct": float(pct),
            "correct": float(correct),
            "total": int(total),
        })
    else:
        # model header line
        current_model = line.strip()

df = pd.DataFrame(rows)

# Safety check
missing_models = set(MODEL_ORDER) - set(df["model"].unique())
if missing_models:
    raise ValueError(f"Models missing in input file: {missing_models}")

# Enforce explicit ordering
df["model"] = pd.Categorical(
    df["model"],
    categories=MODEL_ORDER,
    ordered=True,
)

# =========================
# PREPARE FOR PLOTTING
# =========================

pivot = (
    df.pivot(index="model", columns="label", values="accuracy_pct")
      .loc[MODEL_ORDER]
)
pivot = pivot[["building_element", "inventory_item"]]

# =========================
# PLOT
# =========================

fig, ax = plt.subplots(figsize=FIGSIZE)

pivot_display = pivot.rename(columns=LEGEND_LABELS)

pivot_display.plot(
    kind="barh",
    ax=ax,
)

ax.set_xlim(0, 100)
ax.set_xlabel("Attribute Accuracy (%)")
ax.set_ylabel("")
ax.legend(
    title="",
    loc="lower right",
    fontsize=7.5,          # <- change this
)

# Annotate bars with percentage and (correct/total)
for i, model in enumerate(MODEL_ORDER):
    for j, label in enumerate(pivot.columns):
        row = df[(df["model"] == model) & (df["label"] == label)].iloc[0]
        pct = row["accuracy_pct"]
        text = f"{pct:.1f}%"

        ax.text(
            pct + 0.5,
            i + (j - 0.5) * 0.2,
            text,
            va="center",
            fontsize=8,
        )

plt.tight_layout()

# =========================
# SAVE OUTPUT
# =========================

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
plt.savefig(OUTPUT_PNG, dpi=DPI, bbox_inches="tight")
plt.close()

print(f"Saved plot to {OUTPUT_PNG}")
