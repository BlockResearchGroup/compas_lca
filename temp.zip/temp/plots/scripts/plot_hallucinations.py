import re
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
from matplotlib.patches import Patch


REPORT_PATH = Path("temp/plots/scripts/hallucination_rate.txt")
OUTPUT_PNG  = Path("temp/plots/figures/labels/hallucination_omission_rates.png")  # base name; will create _building_element / _inventory_item

# Color palette grouped by model family
MODEL_COLORS = {
    # Anthropic
    "Opus 4.5":   "#1f77b4",
    "Sonnet 4.5": "#4fa3d1",
    "Haiku 4.5":  "#9ecae1",

    # Gemini
    "Gemini 3 Pro":   "#2ca02c",
    "Gemini 3 Flash": "#98df8a",

    # GPT
    "GPT-5.2":    "#d62728",
    "GPT-5 Mini": "#ff9896",
}

MODEL_ORDER = [
    "Opus 4.5", "Sonnet 4.5", "Haiku 4.5",
    "Gemini 3 Pro", "Gemini 3 Flash",
    "GPT-5.2", "GPT-5 Mini"
]

ENTITY_ORDER = ["building_element", "inventory_item"]
ENTITY_DISPLAY = {
    "building_element": "Building Elements/Layers",
    "inventory_item": "Inventory Items",
}

METRIC_ORDER = ["Hallucination rate", "Omission rate"]

# Matches: "building_element        4.62% (124 / 2685)"
ROW_RE = re.compile(
    r"^\s{4}(building_element|inventory_item)\s+(\d+(?:\.\d+)?)%\s+\(([\d.]+)\s*/\s*([\d.]+)\)\s*$"
)
# Matches section header: "=== Hallucination rate ==="
SECTION_RE = re.compile(r"^===\s*(.+?)\s*===\s*$")


def parse_rates_report(path: Path) -> pd.DataFrame:
    rows = []
    current_metric = None
    current_model = None

    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.rstrip()
        if not line:
            continue

        m_section = SECTION_RE.match(line)
        if m_section:
            current_metric = m_section.group(1).strip()
            current_model = None
            continue

        m_row = ROW_RE.match(line)
        if m_row:
            if current_metric is None or current_model is None:
                raise ValueError(f"Found data row before metric/model header: {line}")
            label, pct, correct, total = m_row.groups()
            rows.append({
                "metric": current_metric,
                "label": label,
                "model": current_model,
                "pct": float(pct),
            })
            continue

        # If it's not a section header or a data row, treat it as a model name line
        # (e.g., "Opus 4.5")
        if not line.startswith("=") and not line.startswith(" "):
            current_model = line.strip()

    df = pd.DataFrame(rows)
    if df.empty:
        raise ValueError(f"No rows parsed from {path}")
    return df


def plot_two_entity_clustered_by_metric(df: pd.DataFrame, output_base: Path) -> None:
    # Order + sanity
    metrics = [m for m in METRIC_ORDER if m in df["metric"].unique()] + \
              [m for m in df["metric"].unique() if m not in METRIC_ORDER]
    models = [m for m in MODEL_ORDER if m in df["model"].unique()] + \
             [m for m in df["model"].unique() if m not in MODEL_ORDER]
    entities = [e for e in ENTITY_ORDER if e in df["label"].unique()] + \
               [e for e in df["label"].unique() if e not in ENTITY_ORDER]

    # Consistent colors
    model_color = {m: MODEL_COLORS.get(m, "#7f7f7f") for m in models}

    output_base.parent.mkdir(parents=True, exist_ok=True)

    # Use a y-limit that fits small percentages nicely
    global_max = float(df["pct"].max())
    y_max = min(100.0, max(5.0, np.ceil((global_max + 2.0) / 5.0) * 5.0))  # round up to nearest 5

    legend_handles = [
        Patch(facecolor=model_color[m], edgecolor="black", label=m)
        for m in models
    ]


    for entity in entities:
        sub = df[df["label"] == entity].copy()

        pivot = sub.pivot_table(index="metric", columns="model", values="pct", aggfunc="mean")
        pivot = pivot.reindex(index=metrics, columns=models)

        x = np.arange(len(metrics))
        group_width = 0.84
        bar_w = group_width / max(len(models), 1)
        x0 = x - group_width / 2 + bar_w / 2

        fig, ax = plt.subplots(figsize=(5, 2.8), constrained_layout=True)

        for i, model in enumerate(models):
            y = pivot[model].values
            bars = ax.bar(
                x0 + i * bar_w,
                y,
                width=bar_w,
                color=model_color[model],
                edgecolor="black",
                linewidth=0.4,
                zorder=3,
            )

            # annotate inside/near top, black text
            for bar in bars:
                h = bar.get_height()
                if np.isnan(h):
                    continue
                y_pos = h - 0.6 if h >= 1.5 else h + 0.25
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    y_pos,
                    f"{h:.2f}",
                    ha="center",
                    va="top" if h >= 1.5 else "bottom",
                    fontsize=7,
                    color="black",
                    clip_on=True,
                    zorder=4,
                )

        ax.set_title(
            f"{ENTITY_DISPLAY.get(entity, entity)}",
            fontsize=10,
            fontweight="semibold",
            pad=6,
        )
        ax.set_xticks(x)
        ax.set_xticklabels(metrics, rotation=0)
        ax.set_ylabel("Rate (%)")
        ax.set_ylim(0, y_max)
        ax.grid(axis="y", linestyle="-", linewidth=0.3, zorder=0)

        # No legend (since you asked before); add back if needed:
        # ax.legend(models, ncol=4, fontsize=7, frameon=True)

        out_path = output_base.with_name(f"{output_base.stem}_{entity}{output_base.suffix}")
        fig.savefig(out_path, dpi=300, bbox_inches="tight")
        plt.close(fig)


if __name__ == "__main__":
    df = parse_rates_report(REPORT_PATH)
    plot_two_entity_clustered_by_metric(df, OUTPUT_PNG)
    print("Saved plots.")
