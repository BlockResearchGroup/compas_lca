#!/usr/bin/env python3
"""
Plot LLM extraction evaluation summaries from multiple .txt files.

Expected lines (example):
Level 1 match (e.g., material vs component): 198/205 (96.6%)
Level 2 match (level 2 accuracy when level 1 is correct): 191/198 (96.5%)
Level 3 match (level 3 accuracy when level 2 is correct): 172/191 (90.1%)
Full match (level 3 correct): 172/205 (83.9%)
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# Relative or absolute paths to your 9 summary .txt files
# Explicit mapping: (path, display label)
TXT_FILES = [
    (
        "temp/obd_extracted/tests/claude_opus_4_5/0_classification/summary.txt",
        "Opus 4.5",
    ),
    (
        "temp/obd_extracted/tests/claude_sonnet_4_5/0_classification/summary.txt",
        "Sonnet 4.5",
    ),
    (
        "temp/obd_extracted/tests/claude_haiku_4_5/0_classification/summary.txt",
        "Haiku 4.5",
    ),
    (
        "temp/obd_extracted/tests/gemini_3_pro_preview/0_classification/summary.txt",
        "Gemini 3 Pro",
    ),
    (
        "temp/obd_extracted/tests/gemini_3_flash_preview/0_classification/summary.txt",
        "Gemini 3 Flash",
    ),
    (
        "temp/obd_extracted/tests/openai_gpt_5_2/0_classification/summary.txt",
        "GPT-5.2",
    ),
    (
        "temp/obd_extracted/tests/openai_gpt_5_mini/0_classification/summary.txt",
        "GPT-5 Mini",
    ),
]


# Output directory for plots and parsed CSV
OUTDIR = "temp/plots/figures/classification"

# Set to True if you want the figures to pop up interactively
SHOW_FIGURES = False

METRICS = [
    ("Level 1 match", "L1"),
    ("Level 2 match", "L2"),
    ("Level 3 match", "L3"),
    ("Full match", "Full"),
]

# Custom colormap: 50% = red, 75% = yellow, 100% = green
RED_YELLOW_GREEN = LinearSegmentedColormap.from_list(
    "red_yellow_green",
    [
        (0.0, "#d62728"),  # red   (50%)
        (0.5, "#ffeb3b"),  # yellow (75%)
        (1.0, "#2ca02c"),  # green (100%)
    ],
)


# Regex to capture: "<Metric label> ... (96.6%)"
PERCENT_RE = re.compile(r"\((?P<pct>\d+(?:\.\d+)?)%\)")

def parse_summary_file(txt_path: Path) -> Dict[str, float]:
    """
    Returns dict mapping metric short name -> percentage (0..100).
    Raises ValueError if any metric is missing.
    """
    text = txt_path.read_text(encoding="utf-8", errors="replace")
    results: Dict[str, float] = {}

    for long_label, short_label in METRICS:
        # Find the line containing the metric label, then extract the percent in parentheses.
        # We keep it robust: locate the first occurrence of the label and parse percent after it.
        idx = text.find(long_label)
        if idx == -1:
            raise ValueError(f"Missing metric label '{long_label}' in {txt_path}")

        # Extract a window of text after the label to search for the percent.
        window = text[idx : idx + 250]
        m = PERCENT_RE.search(window)
        if not m:
            raise ValueError(f"Could not parse percentage for '{long_label}' in {txt_path}")

        results[short_label] = float(m.group("pct"))

    return results


def build_dataframe(items: List[tuple[Path, str]]) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []

    for path, label in items:
        metrics = parse_summary_file(path)
        rows.append(
            {
                "model": label,        # <-- controlled label
                "path": str(path),
                **metrics,
            }
        )

    df = pd.DataFrame(rows)
    return df



def plot_heatmap(df: pd.DataFrame, outpath: Path) -> None:
    data = df[["L1", "L2", "L3", "Full"]].to_numpy()
    models = df["model"].tolist()
    cols = ["(i)", "(ii)", "(iii)", "Full"]

    fig, ax = plt.subplots(
        figsize=(10, max(3.0, 0.25 * len(models) + 1.5))
    )

    im = ax.imshow(
        data,
        aspect="auto",
        cmap=RED_YELLOW_GREEN,
        vmin=50,
        vmax=100,
    )

    ax.set_yticks(range(len(models)))
    ax.set_yticklabels(models)
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels(cols)

    #ax.set_title("Accuracy Heatmap by Model and Match Level")
    ax.set_xlabel("Identity Gate Choice (Inventory Item)")
    #ax.set_ylabel("Model")

    # Annotate cells with values
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            ax.text(
                j,
                i,
                f"{data[i, j]:.1f}%",
                ha="center",
                va="center",
                fontsize=9,
            )

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Accuracy (%)")

    fig.tight_layout()
    fig.savefig(outpath, dpi=200)
    plt.close(fig)

# =========================
# MAIN EXECUTION
# =========================

def main() -> None:
    items = [(Path(p), label) for p, label in TXT_FILES]

    # Basic validation
    for p, _ in items:
        if not p.exists() or not p.is_file():
            raise FileNotFoundError(f"File not found: {p}")

    outdir = Path(OUTDIR)
    outdir.mkdir(parents=True, exist_ok=True)

    # Parse all summaries into a single dataframe
    df = build_dataframe(items)

    # Persist parsed values for traceability / debugging
    df.to_csv(outdir / "items_parsed_accuracies.csv", index=False)

    # Generate plots
    plot_heatmap(df, outdir / "items_accuracy_heatmap.png")

    if SHOW_FIGURES:
        for fname in [
            "items_accuracy_heatmap.png",
        ]:
            img = plt.imread(outdir / fname)
            plt.figure(figsize=(12, 7))
            plt.imshow(img)
            plt.axis("off")
            plt.title(fname)
        plt.show()

    print("Plots written")

if __name__ == "__main__":
    main()