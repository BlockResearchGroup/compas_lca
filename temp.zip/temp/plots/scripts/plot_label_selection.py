import re
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

REPORT_PATH = Path("temp/plots/scripts/label_selection_accuracy.txt")      # relative path to txt
OUTPUT_PNG  = Path("temp/plots/figures/labels/accuracy_plot.png")  # relative path to output


MODEL_ROW_RE = re.compile(
    r"^\s{8}(.+?)\s{2,}(\d+(?:\.\d+)?)%\s+\(([\d.]+)/(\d+)\)\s*$"
)

# Color palette grouped by model family
MODEL_COLORS = {
    # Anthropic
    "Opus 4.5":   "#1f77b4",  # dark blue
    "Sonnet 4.5": "#4fa3d1",  # medium blue
    "Haiku 4.5":  "#9ecae1",  # light blue

    # Gemini
    "Gemini 3 Pro":   "#2ca02c",  # dark green
    "Gemini 3 Flash": "#98df8a",  # light green

    # GPT
    "GPT-5.2":    "#d62728",  # dark red
    "GPT-5 Mini": "#ff9896",  # light red
}

def parse_report(path: str) -> pd.DataFrame:
    rows = []
    metric = None
    label = None

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue

            # Metric header (no leading spaces, not the === line)
            if not line.startswith(" ") and not line.startswith("="):
                metric = line.strip()
                label = None
                continue

            # Label line (4 spaces)
            if line.startswith("    ") and not line.startswith("        "):
                label = line.strip()
                continue

            # Model row (8 spaces)
            m = MODEL_ROW_RE.match(line)
            if m and metric and label:
                model, acc_pct, num, den = m.groups()
                rows.append({
                    "metric": metric,
                    "label": label,
                    "model": model.strip(),
                    "accuracy_pct": float(acc_pct),
                    "correct": float(num),
                    "total": int(den),
                })

    df = pd.DataFrame(rows)

    # Optional: split label into entity_type + label_name if your file structure implies it
    # In your sample, label is already the entity type for each metric block (building_element/inventory_item).
    # If later you add sublabels, you can extend this.

    return df


def plot_two_entity_clustered_by_metric(
    df: pd.DataFrame,
    output_base: Path,
) -> None:
    # Stable orders (optional but recommended)
    metric_order = ["Application Areas", "Functional Types", "Density", "Loadbearing", "Placement"]
    model_order = [
        "Opus 4.5", "Sonnet 4.5", "Haiku 4.5",
        "Gemini 3 Pro", "Gemini 3 Flash",
        "GPT-5.2", "GPT-5 Mini"
    ]
    entity_order = ["building_element", "inventory_item"]

    metrics = [m for m in metric_order if m in df["metric"].unique()] + \
              [m for m in df["metric"].unique() if m not in metric_order]
    models = [m for m in model_order if m in df["model"].unique()] + \
             [m for m in df["model"].unique() if m not in model_order]
    entities = [e for e in entity_order if e in df["label"].unique()] + \
               [e for e in df["label"].unique() if e not in entity_order]

    # Use explicit family-based colors
    model_color = {}
    for m in models:
        if m in MODEL_COLORS:
            model_color[m] = MODEL_COLORS[m]
        else:
            # Fallback for any unexpected model names
            model_color[m] = "#7f7f7f"

    output_base.parent.mkdir(parents=True, exist_ok=True)

    for entity in entities:
        sub = df[df["label"] == entity].copy()

        # Pivot: rows=metric, cols=model => accuracy
        pivot = sub.pivot_table(index="metric", columns="model", values="accuracy_pct", aggfunc="mean")
        pivot = pivot.reindex(index=metrics, columns=models)

        # Clustered bars
        x = np.arange(len(metrics))
        group_width = 0.82
        bar_w = group_width / max(len(models), 1)
        x0 = x - group_width / 2 + bar_w / 2

        fig, ax = plt.subplots(figsize=(10, 2.5), constrained_layout=True)

        handles = []
        for i, model in enumerate(models):
            y = pivot[model].values
            bars = ax.bar(
                x0 + i * bar_w,
                y,
                width=bar_w,
                color=model_color[model],
                edgecolor="black",
                linewidth=0.4,
                label=model,
                zorder=3,
            )

            for bar in bars:
                height = bar.get_height()
                if np.isnan(height):
                    continue

                # Place text inside bar (slightly below the top)
                y_pos = height - 3 if height >= 8 else height + 1.5

                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    y_pos,
                    f"{height:.1f}",
                    ha="center",
                    va="top" if height >= 8 else "bottom",
                    fontsize=7,
                    color="black",
                    clip_on=True,
                    zorder=4,
                )

            handles.append(bars[0])

        if entity == "building_element":
            label_entity = "Building Elements/Layers"
        else:
            label_entity = "Inventory Items"

        ax.set_title(
            f"Selected Attributes Accuracy — {label_entity}",
            fontsize=10,
            fontweight="semibold",
        )
        ax.set_xticks(x)
        ax.set_xticklabels(metrics, rotation=0)
        ax.set_ylabel("Accuracy (%)")
        ax.set_ylim(0, 100)
        ax.grid(axis="y", linestyle="-", linewidth=0.3, zorder=0)

        # Save one png per entity
        out_path = output_base.with_name(f"{output_base.stem}_{entity}{output_base.suffix}")
        fig.savefig(out_path, dpi=300, bbox_inches="tight")
        plt.close(fig)

if __name__ == "__main__":
    df = parse_report(REPORT_PATH)
    plot_two_entity_clustered_by_metric(df, OUTPUT_PNG)
